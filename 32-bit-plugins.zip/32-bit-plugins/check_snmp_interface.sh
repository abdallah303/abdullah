#!/bin/bash

######################################################################
#
# Naigos Plugin For Checking Device Interface Stats via SNMP
# Produces performance Data (Graphs) for TX-Bytes % and RX-Bytes %
#
######################################################################

PROGNAME=`basename $0`
VERSION="Version 1.0"

SNMPGET="$(which snmpget)"
COMMUNITY="public"
ALERT="0"
HOST="localhost"
INTERFACE="1"
NO_OF_SAMPLES="3"
DEVICE="MIKROTIK"
TX_BITS_LOW_THLD="0"
RX_BITS_LOW_THLD="768"


print_help() {
	echo $PROGNAME $VERSION
	echo ""
	echo "Naigos Plugin For Checking Device Interface Stats via SNMP"
        echo "Example: check_snmp_interface.sh -H 190.168.2.10 -C public --description -w 80 -c 90 -I 1"
	echo ""
}


############################################################
# Main
############################################################

while test -n "$1"; do
    case "$1" in
        --help|-h)
            print_help
            exit 3
            ;;
	--version|-v)
            echo $PROGNAME $VERSION
            exit 3
            ;;
	--host|-H)
            HOST=$2
            shift
            ;;
        --community|-C)
            COMMUNITY=$2
            shift
            ;;
        --device|-D)
            DEVICE=$2
            shift
            ;;
	--interface|-I)
            INTERFACE=$2
            shift
            ;;
        --alert|-A)
            ALERT=$2
            shift
            ;;
        --samples|-S)
            NO_OF_SAMPLES=$2
            shift
            ;;
        *)
            echo "Unknown argument: $1"
            print_help
            exit 3
            ;;
        esac
    shift
done

if [ "$DEVICE" == "CISCO" ] ; then

	INTERFACE=`expr $INTERFACE + 48`
	RX_BITS_LOW_THLD=`expr $RX_BITS_LOW_THLD - $RX_BITS_LOW_THLD`
fi

if [ "$DEVICE" == "CISCO-IOS" ] ; then

        INTERFACE=`expr $INTERFACE + 10100`
        RX_BITS_LOW_THLD=`expr $RX_BITS_LOW_THLD - $RX_BITS_LOW_THLD`
fi


	DESCRIPTION=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.2.2.1.2.$INTERFACE 2>/dev/null)
	
	if [ $? -eq 0 ]; then
		DESCRIPTION_READABLE=$( echo $DESCRIPTION | sed 's;";;g' )
	
		LINK_SPEED=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.2.2.1.5.$INTERFACE 2>/dev/null)
		LINK_SPEED_READABLE=$( /usr/local/bin/convert "$LINK_SPEED" )
	
		MAC=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.2.2.1.6.$INTERFACE 2>/dev/null)
		MAC_READABLE=$( echo $MAC | sed 's;";;g' | sed 's; $;;g' |sed 's; ;:;g')
	fi
	
	OPERATOR_STATUS=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.2.2.1.8.$INTERFACE 2>/dev/null)
	
	if [ $? -eq 0 ]; then
	
		if [ "$OPERATOR_STATUS" -eq "1" ] ;  then

			for (( i=1; i <= $NO_OF_SAMPLES; i++ ))
			do
				RX1=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.31.1.1.1.6.$INTERFACE 2>/dev/null)
				TX1=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.31.1.1.1.10.$INTERFACE 2>/dev/null)
				sleep 1
				RX2=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.31.1.1.1.6.$INTERFACE 2>/dev/null)
				TX2=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.31.1.1.1.10.$INTERFACE 2>/dev/null)

				TX_CURRENT=`expr $TX2 - $TX1`
				RX_CURRENT=`expr $RX2 - $RX1`

				# For Debugging ONLY
				#echo "[$i] TX_CURRENT: $TX_CURRENT, RX_CURRENT: $RX_CURRENT"

				TX_TOTAL=`expr $TX_TOTAL + $TX_CURRENT`
				RX_TOTAL=`expr $RX_TOTAL + $RX_CURRENT`

				# For Debugging ONLY
				#echo "[$i] TX_TOTAL: $TX_TOTAL, RX_TOTAL: $RX_TOTAL"
			
				TX_BYTES_AVRG=`expr $TX_TOTAL / $i`
				RX_BYTES_AVRG=`expr $RX_TOTAL / $i`

				# For Debugging ONLY
				#echo "[$i] TX_BYTES_AVRG: $TX_BYTES_AVRG, RX_BYTES_AVRG: $RX_BYTES_AVRG"
			done

				TX_BITS=$(( $TX_BYTES_AVRG * 8 ))
				RX_BITS=$(( $RX_BYTES_AVRG * 8 ))

			TX_BITS_READABLE=$( /usr/local/bin/converthr "$TX_BITS" )
			RX_BITS_READABLE=$( /usr/local/bin/converthr "$RX_BITS" )

			PERF_DATA="| TX_BITS=$TX_BITS; RX_BITS=$RX_BITS;"

			if [ "$RX_BITS" -gt "$RX_BITS_LOW_THLD" ] && [ "$TX_BITS" -gt "$TX_BITS_LOW_THLD" ] ; then

				echo "OK - $DESCRIPTION_READABLE [$MAC_READABLE] is UP @ $LINK_SPEED_READABLE. TX: $TX_BITS_READABLE, RX: $RX_BITS_READABLE $PERF_DATA"
				exit 0

			elif [ "$RX_BITS" -le "$RX_BITS_LOW_THLD" ] ; then

				if [ "$ALERT" -eq "1" ] ; then
					echo "CRITICAL - $DESCRIPTION_READABLE TX: $TX_BITS_READABLE, RX: $RX_BITS_READABLE. Remote END DOWN $PERF_DATA"
					echo "Check Connectivity Medium"
					exit 2
				elif [ "$ALERT" -eq "0" ] ; then
					echo "OK - $DESCRIPTION_READABLE TX: $TX_BITS_READABLE, RX: $RX_BITS_READABLE. Remote END DOWN $PERF_DATA"
					echo "Check Connectivity Medium"
					exit 0
				fi

			elif [ "$TX_BITS" -le "$TX_BITS_LOW_THLD" ] ; then

				if [ "$ALERT" -eq "1" ] ; then
					echo "CRITICAL - $DESCRIPTION_READABLE TX: $TX_BITS_READABLE, RX: $RX_BITS_READABLE. Local END DOWN $PERF_DATA"
					echo "Check Media Converter/Ethernet Cable"
					exit 2
				elif [ "$ALERT" -eq "0" ] ; then
					echo "OK - $DESCRIPTION_READABLE TX: $TX_BITS_READABLE, RX: $RX_BITS_READABLE. Local END DOWN $PERF_DATA"
					echo "Check Media Converter/Ethernet Cable"
					exit 0
				fi
			fi

		elif [ "$OPERATOR_STATUS" -eq "2" ] ;  then


			if [ "$ALERT" -eq "1" ] ; then
				echo "CRITICAL - $DESCRIPTION_READABLE [$MAC_READABLE] is DOWN"
				exit 2
			elif [ "$ALERT" -eq "0" ] ; then
				echo "OK - $DESCRIPTION_READABLE [$MAC_READABLE] is DOWN"
				exit 0
			fi

		fi
	else
			echo "Service Check Timeout"
			exit 3
	fi
