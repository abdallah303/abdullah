#!/bin/bash

################################################################################################
# Description: This script is created for NAGIOS to check how many users are logged in and
#              who are the logged in users.
# Usage:       ./users.sh -w WARNING_USERS_NUMBER -c CRITICAL_USERS_NUMBER
# Usage:       ./users.sh WARNING_USERS_NUMBER CRITICAL_USERS_NUMBER
#
# Developed by: Saad Ali
# Contributed by: Husnain Raza
################################################################################################

VERSION=1.4

WARNING=$1;
CRITICAL=$2;

#USERS_LIST=$(who | awk '{print $1$NF","}' | uniq -c)
USERS_LIST=$(who --ips | awk '{print $1 "(" $NF ")" ","}' | uniq -c)

TOTAL_USERS=$(who | awk '{print $1}' | wc -l)

USERS_OUTPUT="`echo ${USERS_LIST%?}`"

PERF_DATA=" | users=$TOTAL_USERS;$WARNING;$CRITICAL;0;$((CRITICAL+CRITICAL))"


if [ "$TOTAL_USERS" -lt   "$WARNING"  -a "$TOTAL_USERS" -lt "$CRITICAL" ] ;  then

	if [ "$TOTAL_USERS" -eq 0 ]; then
		echo "OK - No User currently logged in" $PERF_DATA
	elif [ "$TOTAL_USERS" -eq 1 ]; then
		echo "OK - $TOTAL_USERS user: $USERS_OUTPUT" $PERF_DATA
	else
		echo "OK - $TOTAL_USERS users: $USERS_OUTPUT" $PERF_DATA
	fi
	exit 0

elif [ "$TOTAL_USERS" -ge "$WARNING" -a "$TOTAL_USERS" -lt "$CRITICAL" ] ;  then

	if [ "$TOTAL_USERS" -eq 1 ]; then
		echo "WARNING - $TOTAL_USERS user: $USERS_OUTPUT" $PERF_DATA
	else
		echo "WARNING - $TOTAL_USERS users: $USERS_OUTPUT" $PERF_DATA
	fi
	exit 1

elif [ "$TOTAL_USERS" -gt "$WARNING" -a "$TOTAL_USERS" -ge "$CRITICAL" ] ;  then

	echo "CRITICAL - $TOTAL_USERS users: $USERS_OUTPUT" $PERF_DATA
	exit 2

else
        echo "Unknown"
        exit 3
fi

