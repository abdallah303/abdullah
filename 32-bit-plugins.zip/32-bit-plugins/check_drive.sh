#!/bin/bash

######################################################################
# Naigos Plugin For Checking Disk Space and Inode
# Accepts seperate Warning and Critical Levels ARGs for Disk & Inode
# Produces performance Data (Graphs) for Disk Used % and Inode Used %


PROGNAME=`basename $0`
VERSION="Version 2.2"
AUTHOR="Husnain Raza"


print_help() {
		echo $PROGNAME $VERSION
		echo $AUTHOR
		echo "Naigos Plugin For Checking Disk Space and Inode"
		echo "Accepts seperate Warning and Critical Levels ARGs for Disk & Inode"
		echo "Produces performance Data (Graphs) for Disk Used % and Inode Used %"
        echo "Usage: check_drive [DISK WARNING %] [DISK CRITICAL %] [INODE WARNING %] [INODE CRITICAL %] [DIR PATH]"
        echo "[WARNING] and [CRITICAL] as int"
        echo "Example: check_drive -dw 80 -dc 90 -iw 90 -ic 95 -p /"
		echo "Example: check_drive --disk-warning 80 --disk-critical 90 --inode-warning 90 --inode-critical 95 --path /mnt"
        exit 3
}


while test -n "$1"; do
    case "$1" in
        -help|-h)
            print_help
            exit 3
            ;;
		--version|-v)
            echo $PROGNAME $VERSION
            exit 3
            ;;
        --disk-warning|-dw)
            DISK_WARNING=$2
            shift
            ;;
        --disk-critical|-dc)
            DISK_CRITICAL=$2
            shift
            ;;
		--inode-warning|-iw)
            INODE_WARNING=$2
            shift
            ;;
        --inode-critical|-ic)
            INODE_CRITICAL=$2
            shift
            ;;
		--path|-p)
            DIR_NAME=$2
            shift
            ;;
        *)
            echo "Unknown argument: $1"
            print_help
            exit 3
            ;;
        esac
    shift
done


if [ ! "$DISK_WARNING" -o ! "$DISK_CRITICAL" -o ! "$INODE_WARNING" -o ! "$INODE_CRITICAL" -o ! "$DIR_NAME" ]; then
		echo "Unknown: Arugments missing"
		print_help
        exit 3
fi

if [ "$DISK_WARNING" -ge "$DISK_CRITICAL" -o "$INODE_WARNING" -ge "$INODE_CRITICAL" ]; then
   echo "Unknown: [WARNING] must be smaller than [CRITICAL]"
        exit 3
fi

RESULT=`df -h $DIR_NAME | tail -1`
DISK_USED_PER=`echo $RESULT | awk '{print substr($5,1,length($5)-1)}'`
DISK_FREE_PER=$((100-DISK_USED_PER));

INODE_RESULT=`df -hi $DIR_NAME | tail -1`
if [ "`uname -s`" = "Linux" ] ; then
	INODE_USED_PER=`echo $INODE_RESULT | awk '{print substr($5,1,length($5)-1)}'`
elif [ "`uname -s`" = "FreeBSD" ] ; then
	INODE_USED_PER=`echo $INODE_RESULT | awk '{print substr($8,1,length($8)-1)}'`
fi

TOTAL_SPACE=`echo $RESULT | awk '{print $2}'`
USED_SPACE=`echo $RESULT | awk '{print $3}'`
FREE_SPACE=`echo $RESULT | awk '{print $4}'`

# DISK_OUTPUT=" $DIR_NAME - total: $TOTAL_SPACE - used: $USED_SPACE ($DISK_USED_PER%) - free $FREE_SPACE ($DISK_FREE_PER%) [ Inode used: $INODE_USED_PER% ]"
# DISK_OUTPUT="$DISK_USED_PER% used ($FREE_SPACE free out of $TOTAL_SPACE)"
DISK_OUTPUT="$DISK_USED_PER% used (Total: $TOTAL_SPACE Free:$FREE_SPACE)"
INODE_OUTPUT="[Inode used: $INODE_USED_PER%]"

DISK_LONG_OUTPUT="Disk_Used=$DISK_USED_PER%"
INODE_LONG_OUTPUT="Inode_Used=$INODE_USED_PER%"

PERF_DATA=" | disk-used=$DISK_USED_PER%;$DISK_WARNING;$DISK_CRITICAL;0;100 inode-used=$INODE_USED_PER%;$INODE_WARNING;$INODE_CRITICAL;0;100"

if [ "$DISK_USED_PER" -lt "$DISK_WARNING" -a "$INODE_USED_PER" -lt "$INODE_WARNING" ]; then
        echo "OK: $DIR_NAME -" $DISK_OUTPUT $INODE_OUTPUT $PERF_DATA
		echo $DISK_LONG_OUTPUT
		echo $INODE_LONG_OUTPUT
        exit 0
 elif [  "$DISK_USED_PER" -ge "$DISK_WARNING" -a "$DISK_USED_PER" -lt "$DISK_CRITICAL" -o "$INODE_USED_PER" -ge "$INODE_WARNING" -a "$INODE_USED_PER" -lt "$INODE_CRITICAL" ]; then
		if [ "$DISK_USED_PER" -ge "$DISK_WARNING" -a "$DISK_USED_PER" -lt "$DISK_CRITICAL" ]; then
			echo "Warning: $DIR_NAME -" $DISK_OUTPUT $PERF_DATA
			echo $DISK_LONG_OUTPUT
		elif [ "$INODE_USED_PER" -ge "$INODE_WARNING" -a "$INODE_USED_PER" -lt "$INODE_CRITICAL" ]; then
			echo "Warning: $DIR_NAME -" $INODE_OUTPUT $PERF_DATA
			echo $INODE_LONG_OUTPUT
		fi
		exit 1
 elif [ "$DISK_USED_PER" -ge "$DISK_CRITICAL" -o "$INODE_USED_PER" -ge "$INODE_CRITICAL" ]; then
		if [ "$DISK_USED_PER" -ge "$DISK_CRITICAL" ]; then
			echo "Critical: $DIR_NAME -" $DISK_OUTPUT $PERF_DATA
			echo $DISK_LONG_OUTPUT
		elif [ "$INODE_USED_PER" -ge "$INODE_CRITICAL" ]; then
			echo "Critical: $DIR_NAME -" $INODE_OUTPUT $PERF_DATA	 
			echo $INODE_LONG_OUTPUT
		fi
        exit 2
 else
        echo "Unknown"
        exit 3
fi
