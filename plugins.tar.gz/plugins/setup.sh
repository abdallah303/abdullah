#!/bin/bash

############################################################
# core functions
############################################################
function check_sanity {
    # Do some sanity checking.
    if [ $(/usr/bin/id -u) != "0" ]
    then
        die 'Must be run by root user'
    fi

    if [ ! -f /etc/debian_version ]
    then
        die "Distribution is not supported"
    fi
}

function check_install {
    if [ -z "`which "$1" 2>/dev/null`" ]
    then
        executable=$1
        shift
        while [ -n "$1" ]
        do
            DEBIAN_FRONTEND=noninteractive apt-get -q -y install "$1"
            print_info "$1 installed successfully"
            shift
        done
    else
        print_warn "$1 already installed"
    fi

    # workaround for some broken templates on VPS
    apt-get -q -y install $1
}

function check_remove {
    if [ -n "`which "$1" 2>/dev/null`" ]
    then
        DEBIAN_FRONTEND=noninteractive apt-get -q -y remove --purge "$1"
        print_info "$1 removed successfully"
    else
        print_warn "$1 is not installed"
    fi
}

function apt_clean_all {
    apt-get clean all
}

function update_upgrade {
    # Run through the apt-get update/upgrade first. This should be done before
    # we try to install any package
    apt-get -q -y update
    apt-get -q -y upgrade

    # also remove the orphaned stuf
    apt-get -q -y autoremove
}

function update_timezone {
    dpkg-reconfigure tzdata
}

function die {
    echo "ERROR: $1" > /dev/null 1>&2
    exit 1
}

function print_info {
    echo -n -e '\e[1;36m'
    echo -n $1
    echo -e '\e[0m'
}

function print_warn {
    echo -n -e '\e[1;33m'
    echo -n $1
    echo -e '\e[0m'
}

function print_critical {
    echo -n -e '\e[1;37;41m'
    echo -n $1
    echo -e '\e[0m'
}

############################################################
# Print OS summary (OS, ARCH, VERSION)
############################################################
function show_os_arch_version {
    # Thanks for Mikel (http://unix.stackexchange.com/users/3169/mikel) for the code sample which was later modified a bit
    # http://unix.stackexchange.com/questions/6345/how-can-i-get-distribution-name-and-version-number-in-a-simple-shell-script
    ARCH=$(uname -m | sed 's/x86_//;s/i[3-6]86/32/')

    if [ -f /etc/lsb-release ]; then
        . /etc/lsb-release
        OS=$DISTRIB_ID
        VERSION=$DISTRIB_RELEASE
    elif [ -f /etc/debian_version ]; then
        # Work on Debian and Ubuntu alike
        OS=$(lsb_release -si)
        VERSION=$(lsb_release -sr)
    elif [ -f /etc/redhat-release ]; then
        # Add code for Red Hat and CentOS here
        OS=Redhat
        VERSION=$(uname -r)
    else
        # Pretty old OS? fallback to compatibility mode
        OS=$(uname -s)
        VERSION=$(uname -r)
    fi

    OS_SUMMARY=$OS
    OS_SUMMARY+=" "
    OS_SUMMARY+=$VERSION
    OS_SUMMARY+=" "
    OS_SUMMARY+=$ARCH
    OS_SUMMARY+="bit"

    print_info "$OS_SUMMARY"
}

############################################################
# Configures Basic VPS (lighttpd etc)
############################################################
function install_webserver_show_parking_page {
    # Install and configure the lighttpd server
    check_install lighttpd lighttpd
    cd /var/www
    wget bo.lowend.org -O index.html
    service lighttpd restart
    print_info "lighttpd server is now installed and running"
}

############################################################
# Install Nagios (server)
############################################################
function install_nagios {
    print_warn "Installing NAGIOS (server), make sure you have basic system installed"
    check_install nagios3 nagios3
    check_install nagios-nrpe-plugin nagios-nrpe-plugin
}

############################################################
# Install Nagios (client)
############################################################
function install_nagiosclient {
    print_warn "Installing NAGIOS (client), make sure you have basic system installed"
    update_upgrade
    check_install nagios-nrpe-server nagios-nrpe-server
    /usr/lib/nagios/plugins/check_apt -u

    print_warn "Downloading the uptime plugin"
    wget labs.asimz.com/check_uptime3 -O /usr/lib/nagios/plugins/check_uptime3
    chmod 777 /usr/lib/nagios/plugins/check_uptime3

    print_info "Writing config file ... DONE"
    cat > /etc/nagios/nrpe.d/asim.cfg <<END
allowed_hosts=109.169.51.81,192.184.95.200
command[check_all_disks]=/usr/lib/nagios/plugins/check_disk -w 20% -c 10% -m -p /
command[check_zombie_procs]=/usr/lib/nagios/plugins/check_procs -w 5 -c 10 -s Z
command[check_procs]=/usr/lib/nagios/plugins/check_procs -w 200 -c 250
command[check_users]=/usr/lib/nagios/plugins/check_users -w 2 -c 5
command[check_load]=/usr/lib/nagios/plugins/check_load -w 15,10,5 -c 30,25,20
command[check_apt]=/usr/lib/nagios/plugins/check_apt
command[check_uptime]=/usr/lib/nagios/plugins/check_uptime3 -c 180
command[check_swap]=/usr/lib/nagios/plugins/check_swap -w 50% -c 30%
command[check_mailq]=/usr/lib/nagios/plugins/check_mailq -w 5 -c 20
END

    print_info "Verifying config file ... "
    cat /etc/nagios/nrpe.d/asim.cfg | grep allowed_hosts
    print_info " ... DONE"
    print_warn "Restarting 'nagios-nrpe-server' ..."
    /etc/init.d/nagios-nrpe-server restart
    print_warn "... DONE"
}


############################################################
# Cleaning up NAGIOS (client)
############################################################
function install_nagiosclientclean {
    print_info "Cleaning up NAGIOS (client)... "
    check_remove nagios-nrpe-server nagios-nrpe-server
    update_upgrade
    print_info "... DONE"
}

############################################################
# Install snmpd client for Cacti/Munin/Observium
############################################################
function install_snmpclient {
    update_upgrade
    check_install snmpd snmpd
    check_install snmp snmp

    print_info "Backup up the previous config as /etc/snmp/snmpd_conf.old"
    mv /etc/snmp/snmpd.conf /etc/snmp/snmpd_conf.old
    # remove all previous snmpd configurations, if any
    rm -fr /etc/snmp/snmpd.conf /etc/snmp/old.snmpd_conf

    print_critical "Type in the ROGroup: [247groupo]"
    read rogroup
    # validate input and fall back to default
    if [[ -z $rogroup ]]
:q
    then
        rogroup="247groupo"
    fi
    print_info "Server group: $rogroup"
    
    
    print_critical "Type in the location of the server: [Cyberspace]"
    read server_location
    # validate input and fall back to default
    if [[ -z $server_location ]]
    then
        server_location="Cyberspace"
    fi
    print_info "Server location: $server_location"    

    cat > /etc/snmp/snmpd.conf <<END
com2sec readonly  default         $rogroup
group $rogroup v1         readonly
group $rogroup v2c        readonly
group $rogroup usm        readonly
view all    included  .1                               80
access $rogroup ""      any       noauth    exact  all    none   none
syslocation "$server_location"
syscontact Asim Zeeshan <critiquebox@gmail.com>
END

    # attempting to write the file on our own
    cat /etc/default/snmpd | grep SNMPDOPTS
    print_warn "Attempting to fix the snmpd defaults automagically..."
    sed -i -e '/SNMPDOPTS=/s/=.*/="-Lsd -Lf \/dev\/null -u snmp -I -smux -p \/var\/run\/snmpd.pid -c \/etc\/snmp\/snmpd.conf"/' /etc/default/snmpd
    cat /etc/default/snmpd | grep SNMPDOPTS
    print_warn "... Done, now restarting snmpd"
    /etc/init.d/snmpd restart
    print_warn "Please do check and update the '/etc/snmp/snmpd.conf' to update community, location and contact"
    
    # check IPv4
    print_info "Checking for valid IPv4 in eth0/venet0:0"
    ipv4=`ifconfig eth0 | awk '/inet addr/ {split ($2,A,":"); print A[2]}'`
    if [[ -z $ipv4 ]]
    then
        ipv4=`ifconfig venet0:0 | awk '/inet addr/ {split ($2,A,":"); print A[2]}'`
    fi
    
    print_critical "You can verify the functionality by doing"
    print_critical "snmpwalk -v 2c -c $rogroup $ipv4"
}

############################################################
# Configure Automatic Updates
# https://help.ubuntu.com/community/AutomaticSecurityUpdates#Using_the_.22unattended-upgrades.22_package
############################################################
function config_autoupdates {
    print_info "Configuring Automatic Upgrades (unattended mode)..."
    check_install unattended-upgrades unattended-upgrades

    cat > /etc/apt/apt.conf.d/10periodic <<END
APT::Periodic::Enable "1";
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "5";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::RandomSleep "1800";
END

    wget labs.asimz.com/50unattended-upgrades -O /etc/apt/apt.conf.d/50unattended-upgrades
    print_info "... DONE"
}

############################################################
# Install and configure logwatch
# Taken from my GIST: https://gist.github.com/4006677
############################################################
function install_configure_logwatch {
    apt_clean_all
    update_upgrade
    update_timezone
    check_install logwatch logwatch
    check_install cron cron

    # -----------------------------------------------------
    # CONFIGURE Logwatch via bash/perl
    # -----------------------------------------------------
    print_critical "Type in your email address: [asim@yho.me]"
    read logwatch_email
    # validate input and fall back to default
    if [[ -z $logwatch_email ]]
    then
        logwatch_email="asim@yho.me"
    fi
    print_info "Email address: $logwatch_email"
    
    print_warn "Attempting to autoconfigure logwatch"
    sed -i -e '/Output =/ s/= .*/= mail/' /usr/share/logwatch/default.conf/logwatch.conf
    sed -i -e "/MailTo =/ s/= .*/= $logwatch_email/" /usr/share/logwatch/default.conf/logwatch.conf
    sed -i -e '/Detail =/ s/= .*/= Med/' /usr/share/logwatch/default.conf/logwatch.conf
    print_info "Everything seems to be fine, unless there are error above"
    print_info "run the following script and see if you get any email ..."
    print_info "/usr/share/logwatch/scripts/logwatch.pl"
}

function download_webmon {
    if [ -d /var/www ]; then
        cd /var/www
        wget labs.asimz.com/info.zip -O /var/www/webmon.zip
        apt-get install -q -y zip
        apt-get install -q -y php5 php5-cli php5-mysql php5-curl php5-gd php-pear php5-mhash php5-sqlite php5-tidy php5-xmlrpc php5-xsl
        unzip webmon.zip
        rm -fr /var/www/webmon.zip
        service apache2 restart
    fi
}

############################################################
# Misc. little scriptlets
############################################################
function update_timezone {
    dpkg-reconfigure tzdata
}

#-----------------------------------------------------------
# Removed uninstalling rsyslogd subroutine
# I dont plan to run this on very lowend systems
#-----------------------------------------------------------
function remove_unneeded {
    # Some Debian have portmap installed. We don't need that.
    check_remove /sbin/portmap portmap

    # Other packages that seem to be pretty common in standard OpenVZ
    # templates.
    check_remove /usr/sbin/apache2 'apache2*'
    check_remove /usr/sbin/named bind9
    check_remove /usr/sbin/smbd 'samba*'
    check_remove /usr/sbin/nscd nscd

    # Need to stop sendmail as removing the package does not seem to stop it.
    if [ -f /usr/lib/sm.bin/smtpd ]
    then
        invoke-rc.d sendmail stop
        check_remove /usr/lib/sm.bin/smtpd 'sendmail*'
    fi
}

function update_upgrade {
    # Run through the apt-get update/upgrade first. This should be done before
    # we try to install any package
    apt-get -q -y update
    apt-get -q -y upgrade

    # also remove the orphaned stuf
    apt-get -q -y autoremove
}

function apt_clean_all {
    apt-get clean all
}

function install_zip {
    check_install zip zip
    check_install unzip unzip
}

function install_rsync {
    check_install rsync rsync
}

function install_vim {
    check_install vim vim
}

function install_nano {
    check_install nano nano
}

function install_htop {
    check_install htop htop
}

function install_mc {
    check_install mc mc
}

function install_iotop {
    check_install iotop iotop
}

function install_iftop {
    check_install iftop iftop
    print_warn "Run IFCONFIG to find your net. device name"
    print_warn "Example usage: iftop -i venet0"
}

########################################################################
# START OF PROGRAM
########################################################################
## export PATH=/bin:/usr/bin:/sbin:/usr/sbin

check_sanity

case "$1" in
system)
    update_timezone
    remove_unneeded
    update_upgrade
    install_zip
    install_rsync
    install_vim
    install_nano
    install_htop
    install_mc
    install_iotop
    install_iftop
	;;
pp)
    install_webserver_show_parking_page
    ;;
quick)
    # install system
    update_timezone
    remove_unneeded
    update_upgrade
    install_zip
    install_rsync
    install_vim
    install_nano
    install_htop
    install_mc
    install_iotop
    install_iftop
    # install nagiosplugin
    install_nagiosclient
    # install logwatch
    install_configure_logwatch
    ;;
nagios)
    install_nagios
    ;;
nagiosclient)
    install_nagiosclient
    ;;
nagiosclientclean)
    install_nagiosclientclean
    ;;
snmpd)
    install_snmpclient
    ;;
logwatch)
    install_configure_logwatch
    ;;
webmon)
    download_webmon
    ;;
autoupdates)
    config_autoupdates
    ;;
upgrade)
    update_upgrade
    check_install aptitude aptitude
    aptitude update && aptitude full-upgrade
    apt-get -q -y autoremove
    ;;
*)
    show_os_arch_version
    echo '  '
    echo 'Usage:' `basename $0` '[option] [argument]'
    echo 'Available options:'
    echo '  - system                (cleans up the system and installs necessary items)'
    echo '  - quick                 (Shortcut for system, nagios and logwatch installation)'
    echo '  - pp                    (Installs lighttpd and adds a parking page)'
    echo '  - upgrade               (apt-get update / upgrade including aptitude)'
    echo '  - nagios                (installs nagios server)'
    echo '  - nagiosclient          (installs nagios-client and configures it)'
    echo '  - nagiosclientclean     (removes nagios-client and all related libraries)'
    echo '  - logwatch              (installs and configure logwatch)'
    echo '  - snmpd                 (installs snmpd client for Observium, Cacti and Munin)'
    echo '  - webmon                (installs apache, php and a bunch of PHP scripts for http-status)'
    echo '  - autoupdates           (configures the system to auto-install important updates)'
    echo '  '
    ;;
esac
