#!/bin/bash

######################################################################
#
# Naigos Plugin For Checking Ubnt NanoBridge Stats via SNMP
# SNMP OIDs are hardcoded in script forUbnt NanoBridge M5
# Produces performance Data (Graphs) for Disk Used % and Inode Used %
#
######################################################################

PROGNAME=`basename $0`
VERSION="Version 1.0"

SNMPGET="$(which snmpget)"
COMMUNITY="public"
WARNING=0
CRITICAL=0
HOST="localhost"
SIGNAL_STRENGTH=0
TX_RATE=0
RX_RATE=0
FREQ=0

print_help() {
	echo $PROGNAME $VERSION
	echo ""
	echo "Naigos Plugin For Checking Ubnt NanoBridge Stats via SNMP"
	echo "SNMP OIDs are hardcoded in script forUbnt NanoBridge M5"
    echo "Example: check_snmp.sh -H 190.168.2.10 -C public -w 80 -c 90 -i"
	echo ""
}


############################################################
# core functions
############################################################

device-uptime() {
	UPTIME=$($SNMPGET -v 1 -c $COMMUNITY -Ov $HOST .1.3.6.1.2.1.1.3.0 2>/dev/null)
	
	if [ $? -eq 0 ]; then
	
		# Because this value is 100th of a sec so divide it by 6000 to convert it in minutes
		UPTIME_MINUTES=$(( $(echo $UPTIME | awk '{print $2}' | sed 's;(;;g' | sed 's;);;g' ) / 6000 ))

		UPTIME_DECR=$( echo $UPTIME | cut -d ')' -f 2 | sed 's;^ ;;g' | cut -d ':' -f 1,2 )

		PERF_DATA="| Uptime_Min=$UPTIME_MINUTES;$WARNING;$CRITICAL;0;"


			if [ "$UPTIME_MINUTES" -lt "$CRITICAL" ] ;  then

					echo "CRITICAL - rebooted $UPTIME_DECR (hr:min) ago $PERF_DATA"
					exit 2

			elif [ "$UPTIME_MINUTES" -le "$WARNING" -a "$UPTIME_MINUTES" -gt "$CRITICAL" ] ;  then

					echo "WARNING - rebooted $UPTIME_DECR (hr:min) ago $PERF_DATA"
					exit 1

			elif [ "$UPTIME_MINUTES" -gt "$WARNING" ] ;  then

					echo "OK - Not rebooted since $UPTIME_DECR (hr:min) $PERF_DATA"
					exit 0

			else
					echo "Unknown"
					exit 3
			fi
	else
			echo "Stats Unavailable at the moment"
			exit 0
	fi
}


signal-strength() {
	SIGNAL_STRENGTH=$($SNMPGET -v 1 -c $COMMUNITY -Oqv $HOST .1.3.6.1.4.1.14988.1.1.1.1.1.4.5 2>/dev/null)
	
	if [ $? -eq 0 ]; then
	
		TX_RATE=$($SNMPGET -v 1 -c $COMMUNITY -Oqv $HOST .1.3.6.1.4.1.14988.1.1.1.1.1.2.5 2>/dev/null)
		RX_RATE=$($SNMPGET -v 1 -c $COMMUNITY -Oqv $HOST .1.3.6.1.4.1.14988.1.1.1.1.1.3.5 2>/dev/null)
		FREQ=$($SNMPGET -v 1 -c $COMMUNITY -Oqv $HOST .1.3.6.1.4.1.14988.1.1.1.1.1.7.5 2>/dev/null)
		
		TX_RATE_MB=$(echo "scale=0; $TX_RATE/1000000" | bc -l)
		RX_RATE_MB=$(echo "scale=0; $RX_RATE/1000000" | bc -l)	
		
		PERF_DATA=" | Signal-dBm=$SIGNAL_STRENGTH;$WARNING;$CRITICAL;-95;-35"

		if [ "$SIGNAL_STRENGTH" -gt "$WARNING" ] ;  then

			echo "OK: Signal Strength [$SIGNAL_STRENGTH dBm] TX/RX [$TX_RATE_MB Mbps/$RX_RATE_MB Mbps] Frequency [$FREQ MHz] $PERF_DATA"
			exit 0

		elif [ "$SIGNAL_STRENGTH" -le "$WARNING" -a "$SIGNAL_STRENGTH" -gt "$CRITICAL" ] ;  then

			echo "WARNING: Signal Strength [$SIGNAL_STRENGTH dBm] $PERF_DATA"
			exit 1

		elif [ "$SIGNAL_STRENGTH" -le "$CRITICAL" ] ;  then

			echo "CRITICAL: Signal Strength [$SIGNAL_STRENGTH dBm] $PERF_DATA"
			exit 2

		else
			echo "Unknown"
			exit 3
		fi
	else
			echo "Stats Unavailable at the moment"
			exit 0
	fi
}


############################################################
# Main
############################################################

while test -n "$1"; do
    case "$1" in
        --help|-h)
            print_help
            exit 3
            ;;
	--version|-v)
            echo $PROGNAME $VERSION
            exit 3
            ;;
	--signal-strength|-ss)
            signal-strength
            shift
            ;;
	--uptime|-u)
            device-uptime
            shift
            ;;
	--host|-H)
            HOST=$2
            shift
            ;;
        --community|-C)
            COMMUNITY=$2
            shift
            ;;
        --warning|-w)
            WARNING=$2
            shift
            ;;
        --critical|-c)
            CRITICAL=$2
            shift
            ;;
        *)
            echo "Unknown argument: $1"
            print_help
            exit 3
            ;;
        esac
    shift
done
