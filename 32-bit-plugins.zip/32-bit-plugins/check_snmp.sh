#!/bin/bash

######################################################################
#
# Naigos Plugin For Checking Mikrotik Stats via SNMP
# SNMP OIDs are hardcoded in script for Mikrotik RouterOS RB750GL
# Produces performance Data (Graphs) for Disk Used % and Inode Used %
#
######################################################################

PROGNAME=`basename $0`
VERSION="Version 1.0"

SNMPGET="$(which snmpget)"
COMMUNITY="public"
WARNING=0
CRITICAL=0
HOST="localhost"


print_help() {
	echo $PROGNAME $VERSION
	echo ""
	echo "Naigos Plugin For Checking Mikrotik Stats via SNMP"
	echo "SNMP OIDs are hardcoded in script for Mikrotik RouterOS RB750GL"
        echo "Example: check_snmp.sh -H 190.168.2.10 -C public -w 80 -c 90 -i"
	echo ""
}


############################################################
# core functions
############################################################

device-uptime() {
	UPTIME=$($SNMPGET -v 2c -c $COMMUNITY -Ov $HOST .1.3.6.1.2.1.1.3.0 2>/dev/null)
	
	if [ $? -eq 0 ]; then
	
		# Because this value is 100th of a sec so divide it by 6000 to convert it in minutes
		UPTIME_MINUTES=$(( $(echo $UPTIME | awk '{print $2}' | sed 's;(;;g' | sed 's;);;g' ) / 6000 ))

		UPTIME_DECR=$( echo $UPTIME | cut -d ')' -f 2 | sed 's;^ ;;g' | cut -d ':' -f 1,2 )

		PERF_DATA="| Uptime_Min=$UPTIME_MINUTES;$WARNING;$CRITICAL;0;"


			if [ "$UPTIME_MINUTES" -lt "$CRITICAL" ] ;  then

					echo "CRITICAL - rebooted $UPTIME_DECR (hr:min) ago $PERF_DATA"
					exit 2

			elif [ "$UPTIME_MINUTES" -le "$WARNING" -a "$UPTIME_MINUTES" -gt "$CRITICAL" ] ;  then

					echo "WARNING - rebooted $UPTIME_DECR (hr:min) ago $PERF_DATA"
					exit 1

			elif [ "$UPTIME_MINUTES" -gt "$WARNING" ] ;  then

					echo "OK - Not rebooted since $UPTIME_DECR (hr:min) $PERF_DATA"
					exit 0

			else
					echo "Unknown"
					exit 3
			fi
	else
			echo "Service Check Timeout"
			exit 3
	fi
}


memory-usage() {
	TOTAL_MEMORY=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.25.2.3.1.5.65536 2>/dev/null)
	USED_MEMORY=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.25.2.3.1.6.65536 2>/dev/null)
	
	if [ $? -eq 0 ]; then
	
		USED_MEMORY_PERCENT=$(( $USED_MEMORY*100/$TOTAL_MEMORY ))

		TOTAL_MEMORY_MB=$(echo "scale=2; $TOTAL_MEMORY/1024" | bc -l)
		USED_MEMORY_MB=$(echo "scale=2; $USED_MEMORY/1024" | bc -l)

		PERF_DATA=" | Mem-Used-%=$USED_MEMORY_PERCENT%;$WARNING;$CRITICAL;0;100"

		if [ "$USED_MEMORY_PERCENT" -lt "$WARNING" ] ;  then

			echo "OK: $USED_MEMORY_MB MB [$USED_MEMORY_PERCENT%] used of total $TOTAL_MEMORY_MB MB RAM $PERF_DATA"
			exit 0

		elif [ "$USED_MEMORY_PERCENT" -ge "$WARNING" -a "$USED_MEMORY_PERCENT" -lt "$CRITICAL" ] ;  then

			echo "WARNING: $USED_MEMORY_MB MB [$USED_MEMORY_PERCENT%] used of total $TOTAL_MEMORY_MB MB RAM $PERF_DATA"
			exit 1

		elif [ "$USED_MEMORY_PERCENT" -ge "$CRITICAL" ] ;  then

			echo "CRITICAL: $USED_MEMORY_MB MB [$USED_MEMORY_PERCENT%] used of total $TOTAL_MEMORY_MB MB RAM $PERF_DATA"
			exit 2

		else
			echo "Unknown"
			exit 3
		fi
	else
			echo "Service Check Timeout"
			exit 3
	fi
}

disk-usage() {
	TOTAL_DISK=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.25.2.3.1.5.131073 2>/dev/null)
	USED_DISK=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.25.2.3.1.6.131073 2>/dev/null)
	
	if [ $? -eq 0 ]; then	
		
		FREE_DISK=$(( $TOTAL_DISK - $USED_DISK ))

		USED_DISK_PERCENT=$(( $USED_DISK*100/$TOTAL_DISK ))

		TOTAL_DISK_MB=$(echo "scale=2; $TOTAL_DISK/1024" | bc -l)
		USED_DISK_MB=$(echo "scale=2; $USED_DISK/1024" | bc -l)
		FREE_DISK_MB=$(echo "scale=2; $FREE_DISK/1024" | bc -l)

		PERF_DATA="| Disk-Used-%=$USED_DISK_PERCENT%;$WARNING;$CRITICAL;0;100"

		if [ "$USED_DISK_PERCENT" -lt "$WARNING" ] ;  then

			echo "OK: $USED_DISK_MB MB [$USED_DISK_PERCENT%] used (Total:$TOTAL_DISK_MB MB Free:$FREE_DISK_MB MB) $PERF_DATA"
			exit 0

		elif [ "$USED_DISK_PERCENT" -ge "$WARNING" -a "$USED_DISK_PERCENT" -lt "$CRITICAL" ] ;  then

			echo "WARNING: $USED_DISK_MB MB [$USED_DISK_PERCENT%] used (Total:$TOTAL_DISK_MB MB Free:$FREE_DISK_MB MB) $PERF_DATA"
			exit 1

		elif [ "$USED_DISK_PERCENT" -ge "$CRITICAL" ] ;  then

			echo "CRITICAL: $USED_DISK_MB MB [$USED_DISK_PERCENT%] used (Total:$TOTAL_DISK_MB MB Free:$FREE_DISK_MB MB) $PERF_DATA"
			exit 2

		else
			echo "Unknown"
			exit 3
		fi
	else
			echo "Service Check Timeout"
			exit 3
	fi
}

processor-usage() {
	PROC_USED_PERCENT=$($SNMPGET -v 2c -c $COMMUNITY -Oqv $HOST .1.3.6.1.2.1.25.3.3.1.2.1 2>/dev/null)
	
	if [ $? -eq 0 ]; then
		
		PERF_DATA="| CPU-Load-%=$PROC_USED_PERCENT%;$WARNING;$CRITICAL;0;100"

		if [ "$PROC_USED_PERCENT" -lt "$WARNING" ] ;  then

			echo "OK: $PROC_USED_PERCENT% CPU Load $PERF_DATA"
			exit 0

		elif [ "$PROC_USED_PERCENT" -ge "$WARNING" -a "$PROC_USED_PERCENT" -lt "$CRITICAL" ] ;  then

			echo "WARNING: $PROC_USED_PERCENT% CPU Load $PERF_DATA"
			exit 1

		elif [ "$PROC_USED_PERCENT" -ge "$CRITICAL" ] ;  then

			echo "CRITICAL: $PROC_USED_PERCENT% CPU Load $PERF_DATA"
			exit 2

		else
			echo "Unknown"
			exit 3
		fi
	else
			echo "Service Check Timeout"
			exit 3
	fi
}


############################################################
# Main
############################################################

while test -n "$1"; do
    case "$1" in
        --help|-h)
            print_help
            exit 3
            ;;
	--version|-v)
            echo $PROGNAME $VERSION
            exit 3
            ;;
	--memory-usage|-m)
            memory-usage
            shift
            ;;
	--disk-usage|-d)
            disk-usage
            shift
            ;;
	--processor-usage|-p)
            processor-usage
            shift
            ;;
	--uptime|-u)
            device-uptime
            shift
            ;;
	--identify|-i)
            device-indentify
            shift
            ;;
	--host|-H)
            HOST=$2
            shift
            ;;
        --community|-C)
            COMMUNITY=$2
            shift
            ;;
        --warning|-w)
            WARNING=$2
            shift
            ;;
        --critical|-c)
            CRITICAL=$2
            shift
            ;;
        *)
            echo "Unknown argument: $1"
            print_help
            exit 3
            ;;
        esac
    shift
done
